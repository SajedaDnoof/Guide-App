package com.example.guideapp.model;

public class Hotel {
    private int name;
    private int image;
    private int description;
    private int phone;
    private int address;

    public int getName() {
        return name;
    }

    public void setName(int name) {
        this.name = name;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public int getDescription() {
        return description;
    }

    public void setDescription(int description) {
        this.description = description;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public int getAddress() {
        return address;
    }

    public void setAddress(int address) {
        this.address = address;
    }

    public Hotel(int name, int image, int description, int phone, int address) {

        this.name = name;
        this.image = image;
        this.description = description;
        this.phone = phone;
        this.address = address;
    }
}
