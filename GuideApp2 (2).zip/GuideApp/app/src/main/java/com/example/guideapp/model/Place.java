package com.example.guideapp.model;

public class Place {
    private int name;
    private int image;
    private int description;
    private int address;

    public int getName() {
        return name;
    }

    public void setName(int name) {
        this.name = name;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public int getDescription() {
        return description;
    }

    public void setDescription(int description) {
        this.description = description;
    }


    public int getAddress() {
        return address;
    }

    public void setAddress(int address) {
        this.address = address;
    }

    public Place(int name, int image, int description, int address) {
        this.name = name;
        this.image = image;
        this.description = description;
        this.address = address;
    }
}
