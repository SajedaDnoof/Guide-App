package com.example.guideapp;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.guideapp.model.Hotel;
import com.example.guideapp.model.Shop;

import java.util.ArrayList;
import java.util.List;


public class ShopsFragment extends Fragment {


    private RecyclerView shopsRv;
    public ShopsFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_shops, container, false);
        shopsRv = view.findViewById(R.id.shops_rv);

        ShopsAdapter adapter = new ShopsAdapter();
        shopsRv.setLayoutManager(new LinearLayoutManager(getContext()));
        shopsRv.setAdapter(adapter);

        adapter.setShops(getShops());
        return view;
    }

    private List<Shop> getShops() {
        List<Shop> shops = new ArrayList<>();
        shops.add(new Shop(R.string.shop1, R.drawable.shop, R.string.shop1_desc, R.string.shop1_phone, R.string.shop1_address));
        shops.add(new Shop(R.string.shop2, R.drawable.shop, R.string.shop2_desc, R.string.shop2_phone, R.string.shop2_address));
        shops.add(new Shop(R.string.shop3, R.drawable.shop, R.string.shop3_desc, R.string.shop3_phone, R.string.shop3_address));
        shops.add(new Shop(R.string.shop2, R.drawable.shop, R.string.shop2_desc, R.string.shop2_phone, R.string.shop2_address));
        shops.add(new Shop(R.string.shop3, R.drawable.shop, R.string.shop3_desc, R.string.shop3_phone, R.string.shop3_address));
        return shops;
    }

}
