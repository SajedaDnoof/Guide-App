package com.example.guideapp;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.guideapp.model.Hotel;
import com.example.guideapp.model.Place;

import java.util.List;

public class PlacesAdapter extends RecyclerView.Adapter<PlacesAdapter.MyHolder> {
    private List<Place> places;

    public void setPlaces(List<Place> places) {
        this.places = places;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        View view = inflater.inflate(R.layout.place_item, viewGroup, false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder myHolder, int i) {
        myHolder.nameTv.setText(places.get(i).getName());
        myHolder.descriptionTv.setText(places.get(i).getDescription());
        myHolder.addressTv.setText(places.get(i).getAddress());
        myHolder.restaurantImg.setImageResource(places.get(i).getImage());
    }

    @Override
    public int getItemCount() {
        return places.size();
    }

    class MyHolder extends RecyclerView.ViewHolder{
        TextView nameTv, descriptionTv,addressTv;
        ImageView restaurantImg;
        public MyHolder(@NonNull View itemView) {
            super(itemView);
            nameTv = itemView.findViewById(R.id.name_tv);
            descriptionTv = itemView.findViewById(R.id.description_tv);
            restaurantImg = itemView.findViewById(R.id.restaurants_img);
            addressTv = itemView.findViewById(R.id.address_tv);
        }
    }
}
