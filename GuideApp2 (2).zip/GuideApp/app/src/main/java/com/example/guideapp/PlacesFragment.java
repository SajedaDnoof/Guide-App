package com.example.guideapp;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.guideapp.model.Hotel;
import com.example.guideapp.model.Place;
import com.example.guideapp.model.Shop;

import java.util.ArrayList;
import java.util.List;


public class PlacesFragment extends Fragment {


    private RecyclerView placesRv;
    public PlacesFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_places, container, false);
        placesRv = view.findViewById(R.id.places_rv);

        PlacesAdapter adapter = new PlacesAdapter();
        placesRv.setLayoutManager(new LinearLayoutManager(getContext()));
        placesRv.setAdapter(adapter);
        adapter.setPlaces(getPlaces());
        return view;
    }

    private List<Place> getPlaces() {
        List<Place> places = new ArrayList<>();
        places.add(new Place(R.string.place1, R.drawable.mountant, R.string.place1_desc, R.string.place1_address));
        places.add(new Place(R.string.place2, R.drawable.mountant, R.string.place2_desc, R.string.place2_address));
        places.add(new Place(R.string.place3, R.drawable.mountant, R.string.place3_desc, R.string.place3_address));
        places.add(new Place(R.string.place2, R.drawable.mountant, R.string.place2_desc, R.string.place2_address));
        places.add(new Place(R.string.place1, R.drawable.mountant, R.string.place1_desc, R.string.place1_address));
        places.add(new Place(R.string.place3, R.drawable.mountant, R.string.place3_desc, R.string.place3_address));
        return places;
    }

}
