package com.example.guideapp;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.guideapp.model.Hotel;
import com.example.guideapp.model.Shop;

import java.util.ArrayList;
import java.util.List;


public class HotelsFragment extends Fragment {


    private RecyclerView hotelsRv;

    public HotelsFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_hotels, container, false);
        hotelsRv = view.findViewById(R.id.hotels_rv);

        HotelAdapter adapter = new HotelAdapter();
        hotelsRv.setLayoutManager(new LinearLayoutManager(getContext()));
        hotelsRv.setAdapter(adapter);
        adapter.setHotels(getHotels());
        return view;
    }

    private List<Hotel> getHotels() {
        List<Hotel> hotels = new ArrayList<>();
        hotels.add(new Hotel(R.string.hotel1, R.drawable.hotel1, R.string.hotel1_desc, R.string.hotel1_phone, R.string.hotel1_address));
        hotels.add(new Hotel(R.string.hotel2, R.drawable.hotel2, R.string.hotel2_desc, R.string.hotel2_phone, R.string.hotel2_address));
        hotels.add(new Hotel(R.string.hotel3, R.drawable.hotel3, R.string.hotel3_desc, R.string.hotel3_phone, R.string.hotel3_address));
        hotels.add(new Hotel(R.string.hotel2, R.drawable.hotel2, R.string.hotel2_desc, R.string.hotel2_phone, R.string.hotel2_address));
        hotels.add(new Hotel(R.string.hotel1, R.drawable.hotel1, R.string.hotel1_desc, R.string.hotel1_phone, R.string.hotel1_address));
        hotels.add(new Hotel(R.string.hotel2, R.drawable.hotel2, R.string.hotel2_desc, R.string.hotel2_phone, R.string.hotel2_address));
        hotels.add(new Hotel(R.string.hotel3, R.drawable.hotel3, R.string.hotel3_desc, R.string.hotel3_phone, R.string.hotel3_address));
        return hotels;
    }

}
