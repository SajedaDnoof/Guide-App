package com.example.guideapp;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.guideapp.model.Hotel;
import com.example.guideapp.model.Restaurant;

import java.util.ArrayList;
import java.util.List;


public class RestaurantsFragment extends Fragment {


    private RecyclerView restaurantsRv;

    public RestaurantsFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_restaurants, container, false);
        restaurantsRv = view.findViewById(R.id.restaurants_rv);
        RestaurantsAdapter adapter = new RestaurantsAdapter();
        restaurantsRv.setLayoutManager(new LinearLayoutManager(getContext()));
        restaurantsRv.setAdapter(adapter);

        adapter.setRestaurants(getRestaurants());
        return view;
    }


    private List<Restaurant> getRestaurants(){
        List<Restaurant> restaurants = new ArrayList<>();
        restaurants.add(new Restaurant(R.string.restaurant1, R.drawable.rest1, R.string.restaurant1_desc, R.string.restaurant1_phone, R.string.restaurant1_address));
        restaurants.add(new Restaurant(R.string.restaurant2, R.drawable.rest2, R.string.restaurant2_desc, R.string.restaurant2_phone, R.string.restaurant2_address));
        restaurants.add(new Restaurant(R.string.restaurant3, R.drawable.rest2, R.string.restaurant3_desc, R.string.restaurant3_phone, R.string.restaurant3_address));
        restaurants.add(new Restaurant(R.string.restaurant1, R.drawable.rest1, R.string.restaurant1_desc, R.string.restaurant1_phone, R.string.restaurant1_address));
        restaurants.add(new Restaurant(R.string.restaurant2, R.drawable.rest2, R.string.restaurant2_desc, R.string.restaurant2_phone, R.string.restaurant2_address));
        restaurants.add(new Restaurant(R.string.restaurant3, R.drawable.rest2, R.string.restaurant3_desc, R.string.restaurant3_phone, R.string.restaurant3_address));
        return restaurants;
    }
}
