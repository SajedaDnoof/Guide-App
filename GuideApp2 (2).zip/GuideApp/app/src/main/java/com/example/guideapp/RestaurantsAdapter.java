package com.example.guideapp;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.guideapp.model.Restaurant;

import java.util.List;

public class RestaurantsAdapter extends RecyclerView.Adapter<RestaurantsAdapter.MyHolder> {
    private List<Restaurant> restaurants;

    public void setRestaurants(List<Restaurant> restaurants) {
        this.restaurants = restaurants;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        View view = inflater.inflate(R.layout.restaurant_item, viewGroup, false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder myHolder, int i) {
        myHolder.nameTv.setText(restaurants.get(i).getName());
        myHolder.descriptionTv.setText(restaurants.get(i).getDescription());
        myHolder.addressTv.setText(restaurants.get(i).getAddress());
        myHolder.phoneTv.setText(restaurants.get(i).getPhone());
        myHolder.restaurantImg.setImageResource(restaurants.get(i).getImage());
    }

    @Override
    public int getItemCount() {
        return restaurants.size();
    }

    class MyHolder extends RecyclerView.ViewHolder{
        TextView nameTv, descriptionTv,addressTv,phoneTv;
        ImageView restaurantImg;
        public MyHolder(@NonNull View itemView) {
            super(itemView);
            nameTv = itemView.findViewById(R.id.name_tv);
            descriptionTv = itemView.findViewById(R.id.description_tv);
            restaurantImg = itemView.findViewById(R.id.restaurants_img);
            addressTv = itemView.findViewById(R.id.address_tv);
            phoneTv = itemView.findViewById(R.id.phone_tv);
        }
    }
}
